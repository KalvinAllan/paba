package ReV

data class DataToko(
    var  Nama:String,
    var Stock:Int,
    var Harga:Int,
    var  image: Int,
    var Rating: Double
)
