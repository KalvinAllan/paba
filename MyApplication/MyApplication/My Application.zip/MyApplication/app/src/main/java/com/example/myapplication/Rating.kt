package com.example.myapplication

data class Rating(
    var Rater:ArrayList<String>,
    var Value:ArrayList<Long>,
    var Komentar:ArrayList<String>
)
