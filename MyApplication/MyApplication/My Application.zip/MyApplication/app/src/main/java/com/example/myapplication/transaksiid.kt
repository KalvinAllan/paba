package com.example.myapplication

data class transaksiid(
    var id :Int,
    var namaP:String,
    var nama:String,
    var harga:Int,
    var jumlahbarang:Int,
    var status:Int
)
