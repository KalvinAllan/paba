package com.example.myapplication

import kotlin.collections.ArrayList

data class Data(
    var nama: String,
    var pass: String,
    var transaksiid: ArrayList<Long>
)
