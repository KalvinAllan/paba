package com.example.myapplication

import android.view.LayoutInflater
import android.view.TextureView
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class Adapter (private val data: ArrayList<Data>): RecyclerView.Adapter<Adapter.ListViewHolder>(){
    inner class  ListViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView){
        var nama : TextView=itemView.findViewById(R.id.nama)
        var password : TextView =itemView.findViewById(R.id.password)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ListViewHolder {
        val view: View = LayoutInflater.from(parent.context).inflate(R.layout.isi, parent, false)
        return ListViewHolder(view)

    }

    override fun onBindViewHolder(holder: ListViewHolder, position: Int) {
       var dataItem = data[position]
        holder.nama.setText(dataItem.nama)
        holder.password.setText(dataItem.pass)
    }

    override fun getItemCount(): Int {
        return data.size
    }
}
