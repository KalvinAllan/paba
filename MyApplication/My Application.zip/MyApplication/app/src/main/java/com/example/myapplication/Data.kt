package com.example.myapplication

data class Data(
    var nama: String,
    var pass: String
)
