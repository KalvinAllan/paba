package com.example.myapplication

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase


class Home : AppCompatActivity() {
    private lateinit var nama :Array<String>
    private lateinit var password:Array<String>

    private var ardata = arrayListOf<Data>()
    private fun SiapkanData(){
        val db = Firebase.firestore
        val retrieveData = db.collection("tbData")
            .get()
            .addOnSuccessListener { result->
                for (document in result){
                    val a = document.data.get("nama")
                    nama.plus(a.toString())
                }
            }

    }
    private fun TambahData(){
        for (position in nama.indices){
            val data = Data(
                nama[position],
                password[position]
            )
        }
    }
    private fun TampilkanData(){
        
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)
    }
}